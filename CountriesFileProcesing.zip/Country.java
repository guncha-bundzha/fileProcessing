package Topic_9_File_proc;

import java.util.ArrayList;
import java.util.HashMap;

public class Country {
	String name;
	String region;
	int population;
	boolean hasCoastline;
	int gdp;
	double birthrate;
	double  deathrate;
	int rank;
	double happyRate;
	
	static ArrayList<Country> all = new ArrayList<Country>();
	static HashMap<String,Country> map = new HashMap<String,Country>();

	public Country(String name, String region, int population, boolean hasCoastline, int gdp, double birthrate,
			double deathrate) {
		this.name = name;
		this.region = region;
		this.population = population;
		this.hasCoastline = hasCoastline;
		this.gdp = gdp;
		this.birthrate = birthrate;
		this.deathrate =  deathrate;
		all.add(this);
		Country.map.put(this.name,this);
	}
	static void countEuropeanNoCoastline() {
		int count =0;
		for(Country c: all) {
			if(c.hasCoastline == false && c.region.contains("EUROPE")) {
				count++;
				
			}
		}
		System.out.println("In Europe there are "+count+" countries with no coastline" + "!");
	}
}










