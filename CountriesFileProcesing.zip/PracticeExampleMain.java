package Topic_9_File_proc;

import java.io.File;
import java.util.HashMap;
import java.util.Scanner;

public class PracticeExampleMain {

	static String root = "C:\\Users\\sk8an\\Downloads\\";

	public static void main(String[] args) {

		readCountries();
		readHappiness();
		Country.countEuropeanNoCoastline();
	}

	static void readHappiness() {
		File h = new File(root + "Happiness_rank_2019.csv");

		String del = ",";
		try {
			Scanner scan = new Scanner(h);
			scan.nextLine();
			while (scan.hasNextLine()) {
				String line = scan.nextLine();

				if (line.trim().isEmpty()) {
					continue;

				}
				String[] values = line.split(del);
				String name = values[1].trim();
				int rank = getInt(values[0]);
				double happyRate = getDouble(values[2]);
				
				if(Country.map.containsKey(name)==false) continue;
				System.out.println();
				Country needed = Country.map.get(name);

				
				needed.rank = rank;
				needed.happyRate = happyRate;
				System.out.println(name);

			}
			scan.close();
		} catch (Exception e) {
			System.err.println(e);
		}
	}

	static void readCountries() {
		File f = new File(root + "countries.csv");

		String del = ";";
		try {
			Scanner scan = new Scanner(f);
			scan.nextLine(); // skips header
			while (scan.hasNextLine()) {
				String line = scan.nextLine();

				if (line.replace(del, "").trim().isEmpty()) {
					continue;
				}
				String[] values = line.split(del);
				String name = values[0].trim();
				String region = values[1].trim();
				int pop = getInt(values[2].trim());
				boolean hasCoastline = getDouble(values[5].trim()) > 0;
				int gdp = getInt(values[8].trim());
				double birthrate = getDouble(values[15].trim());
				double deathrate = getDouble(values[16].trim());
				new Country(name, region, pop, hasCoastline, gdp, birthrate, deathrate);
			}
			System.out.println("Imported " + Country.all.size() + " countries");
			scan.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	static int getInt(String string) {
		try {
			return Integer.parseInt(string);
		} catch (Exception e) {
			// System.out.println("Fails int: " + string );
			return 0;
		}
	}

	static double getDouble(String string) {
		try {
			return Double.parseDouble(string);
		} catch (Exception e) {
			// System.out.println("Fails double: "+ string);
			return 0;
		}
	}
}
